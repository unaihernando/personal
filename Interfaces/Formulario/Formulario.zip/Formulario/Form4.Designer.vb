﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form4))
        Me.PictureBoxUS = New System.Windows.Forms.PictureBox()
        Me.PictureBoxEscudos = New System.Windows.Forms.PictureBox()
        Me.PictureBoxIL = New System.Windows.Forms.PictureBox()
        Me.PictureBoxY = New System.Windows.Forms.PictureBox()
        Me.PictureBoxIM = New System.Windows.Forms.PictureBox()
        Me.PictureBoxYB = New System.Windows.Forms.PictureBox()
        Me.PictureBoxDG = New System.Windows.Forms.PictureBox()
        Me.PictureBoxUV = New System.Windows.Forms.PictureBox()
        Me.PictureBoxAL = New System.Windows.Forms.PictureBox()
        Me.PictureBoxMu = New System.Windows.Forms.PictureBox()
        Me.PictureBoxW = New System.Windows.Forms.PictureBox()
        Me.PictureBoxRG = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        CType(Me.PictureBoxUS, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxEscudos, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxIL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxY, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxIM, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxYB, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxDG, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxUV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxAL, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxMu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxW, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBoxRG, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PictureBoxUS
        '
        Me.PictureBoxUS.Image = CType(resources.GetObject("PictureBoxUS.Image"), System.Drawing.Image)
        Me.PictureBoxUS.Location = New System.Drawing.Point(356, 12)
        Me.PictureBoxUS.Name = "PictureBoxUS"
        Me.PictureBoxUS.Size = New System.Drawing.Size(94, 96)
        Me.PictureBoxUS.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxUS.TabIndex = 0
        Me.PictureBoxUS.TabStop = False
        '
        'PictureBoxEscudos
        '
        Me.PictureBoxEscudos.Image = CType(resources.GetObject("PictureBoxEscudos.Image"), System.Drawing.Image)
        Me.PictureBoxEscudos.Location = New System.Drawing.Point(0, 0)
        Me.PictureBoxEscudos.Name = "PictureBoxEscudos"
        Me.PictureBoxEscudos.Size = New System.Drawing.Size(101, 90)
        Me.PictureBoxEscudos.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxEscudos.TabIndex = 1
        Me.PictureBoxEscudos.TabStop = False
        '
        'PictureBoxIL
        '
        Me.PictureBoxIL.Image = CType(resources.GetObject("PictureBoxIL.Image"), System.Drawing.Image)
        Me.PictureBoxIL.Location = New System.Drawing.Point(60, 96)
        Me.PictureBoxIL.Name = "PictureBoxIL"
        Me.PictureBoxIL.Size = New System.Drawing.Size(95, 95)
        Me.PictureBoxIL.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxIL.TabIndex = 2
        Me.PictureBoxIL.TabStop = False
        '
        'PictureBoxY
        '
        Me.PictureBoxY.Image = CType(resources.GetObject("PictureBoxY.Image"), System.Drawing.Image)
        Me.PictureBoxY.Location = New System.Drawing.Point(244, 96)
        Me.PictureBoxY.Name = "PictureBoxY"
        Me.PictureBoxY.Size = New System.Drawing.Size(95, 95)
        Me.PictureBoxY.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxY.TabIndex = 3
        Me.PictureBoxY.TabStop = False
        '
        'PictureBoxIM
        '
        Me.PictureBoxIM.Image = CType(resources.GetObject("PictureBoxIM.Image"), System.Drawing.Image)
        Me.PictureBoxIM.Location = New System.Drawing.Point(456, 96)
        Me.PictureBoxIM.Name = "PictureBoxIM"
        Me.PictureBoxIM.Size = New System.Drawing.Size(95, 95)
        Me.PictureBoxIM.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxIM.TabIndex = 4
        Me.PictureBoxIM.TabStop = False
        '
        'PictureBoxYB
        '
        Me.PictureBoxYB.Image = CType(resources.GetObject("PictureBoxYB.Image"), System.Drawing.Image)
        Me.PictureBoxYB.Location = New System.Drawing.Point(633, 96)
        Me.PictureBoxYB.Name = "PictureBoxYB"
        Me.PictureBoxYB.Size = New System.Drawing.Size(95, 95)
        Me.PictureBoxYB.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxYB.TabIndex = 5
        Me.PictureBoxYB.TabStop = False
        '
        'PictureBoxDG
        '
        Me.PictureBoxDG.Image = CType(resources.GetObject("PictureBoxDG.Image"), System.Drawing.Image)
        Me.PictureBoxDG.Location = New System.Drawing.Point(245, 216)
        Me.PictureBoxDG.Name = "PictureBoxDG"
        Me.PictureBoxDG.Size = New System.Drawing.Size(94, 96)
        Me.PictureBoxDG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxDG.TabIndex = 6
        Me.PictureBoxDG.TabStop = False
        '
        'PictureBoxUV
        '
        Me.PictureBoxUV.Image = CType(resources.GetObject("PictureBoxUV.Image"), System.Drawing.Image)
        Me.PictureBoxUV.Location = New System.Drawing.Point(456, 217)
        Me.PictureBoxUV.Name = "PictureBoxUV"
        Me.PictureBoxUV.Size = New System.Drawing.Size(94, 96)
        Me.PictureBoxUV.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxUV.TabIndex = 7
        Me.PictureBoxUV.TabStop = False
        '
        'PictureBoxAL
        '
        Me.PictureBoxAL.Image = CType(resources.GetObject("PictureBoxAL.Image"), System.Drawing.Image)
        Me.PictureBoxAL.Location = New System.Drawing.Point(60, 277)
        Me.PictureBoxAL.Name = "PictureBoxAL"
        Me.PictureBoxAL.Size = New System.Drawing.Size(95, 95)
        Me.PictureBoxAL.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxAL.TabIndex = 8
        Me.PictureBoxAL.TabStop = False
        '
        'PictureBoxMu
        '
        Me.PictureBoxMu.Image = CType(resources.GetObject("PictureBoxMu.Image"), System.Drawing.Image)
        Me.PictureBoxMu.Location = New System.Drawing.Point(633, 277)
        Me.PictureBoxMu.Name = "PictureBoxMu"
        Me.PictureBoxMu.Size = New System.Drawing.Size(94, 96)
        Me.PictureBoxMu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxMu.TabIndex = 9
        Me.PictureBoxMu.TabStop = False
        '
        'PictureBoxW
        '
        Me.PictureBoxW.Image = CType(resources.GetObject("PictureBoxW.Image"), System.Drawing.Image)
        Me.PictureBoxW.Location = New System.Drawing.Point(244, 343)
        Me.PictureBoxW.Name = "PictureBoxW"
        Me.PictureBoxW.Size = New System.Drawing.Size(95, 95)
        Me.PictureBoxW.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxW.TabIndex = 10
        Me.PictureBoxW.TabStop = False
        '
        'PictureBoxRG
        '
        Me.PictureBoxRG.Image = CType(resources.GetObject("PictureBoxRG.Image"), System.Drawing.Image)
        Me.PictureBoxRG.Location = New System.Drawing.Point(456, 343)
        Me.PictureBoxRG.Name = "PictureBoxRG"
        Me.PictureBoxRG.Size = New System.Drawing.Size(95, 95)
        Me.PictureBoxRG.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBoxRG.TabIndex = 11
        Me.PictureBoxRG.TabStop = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(800, 463)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 12
        Me.PictureBox1.TabStop = False
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.PictureBoxRG)
        Me.Controls.Add(Me.PictureBoxW)
        Me.Controls.Add(Me.PictureBoxMu)
        Me.Controls.Add(Me.PictureBoxAL)
        Me.Controls.Add(Me.PictureBoxUV)
        Me.Controls.Add(Me.PictureBoxDG)
        Me.Controls.Add(Me.PictureBoxYB)
        Me.Controls.Add(Me.PictureBoxIM)
        Me.Controls.Add(Me.PictureBoxY)
        Me.Controls.Add(Me.PictureBoxIL)
        Me.Controls.Add(Me.PictureBoxEscudos)
        Me.Controls.Add(Me.PictureBoxUS)
        Me.Controls.Add(Me.PictureBox1)
        Me.Name = "Form4"
        Me.Text = "Form4"
        CType(Me.PictureBoxUS, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxEscudos, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxIL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxY, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxIM, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxYB, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxDG, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxUV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxAL, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxMu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxW, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBoxRG, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PictureBoxUS As PictureBox
    Friend WithEvents PictureBoxEscudos As PictureBox
    Friend WithEvents PictureBoxIL As PictureBox
    Friend WithEvents PictureBoxY As PictureBox
    Friend WithEvents PictureBoxIM As PictureBox
    Friend WithEvents PictureBoxYB As PictureBox
    Friend WithEvents PictureBoxDG As PictureBox
    Friend WithEvents PictureBoxUV As PictureBox
    Friend WithEvents PictureBoxAL As PictureBox
    Friend WithEvents PictureBoxMu As PictureBox
    Friend WithEvents PictureBoxW As PictureBox
    Friend WithEvents PictureBoxRG As PictureBox
    Friend WithEvents PictureBox1 As PictureBox
End Class
